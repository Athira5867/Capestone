package com.ust.pms.service;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.UstSpringMvcProductApplication;
import com.ust.pms.model.Product;

@SpringBootTest
class ProductServiceTest {
	@Autowired
	ProductService productService;

	@BeforeEach
	public void setUp() {
		//productService=new ProductService();
	}
	@AfterEach
	void tearDown()  throws Exception{
		//productService=null;
	}
	@Test
	public void testGetProduct() throws Exception{
		Product product=new Product(777,"TestProduct",2,1892);
		productService.saveProduct(product);
		Product result=productService.getProduct(777);
		assertTrue(result.getProductId()==777);
		productService.deleteProduct(777);
		
	}
	@Test
	void testSaveProduct() {
		Product product=new Product(7677,"TestProduct",2,1892);
		productService.saveProduct(product);
		assertTrue(productService.isProductExist(7677));
		productService.deleteProduct(7677);
		
	}
	
	
	@Test
	void testDeleteProduct() {
		System.out.println("Inside delete");
		Product product=new Product(777,"TestProduct",2,1892);
		productService.saveProduct(product);
		productService.deleteProduct(777);
		Boolean result=productService.isProductExist(777);
		assertTrue(!result);
	}
	@Test
	void testUpdateProduct() {
		Product product=new Product(777,"TestProduct",2,1892);
		productService.saveProduct(product);
		Product updateProduct=new Product(777,"UpdatedProduct",2,1892);
		productService.saveProduct(updateProduct);
		Product result=productService.getProduct(777);
		assertTrue(result.getProductName().equalsIgnoreCase("UpdatedProduct"));
		productService.deleteProduct(777);
	}
}
