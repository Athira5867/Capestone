
  package com.ust.pms.service;
  
  import static org.junit.jupiter.api.Assertions.*;
  
  import java.util.List;
  
  import org.junit.jupiter.api.AfterEach;
  import org.junit.jupiter.api.BeforeEach; 
  import org.junit.jupiter.api.Test;
  import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.pms.model.Cart;
  @SpringBootTest
  class CartServiceTest {
  
  @Autowired CartService cartService;
  
  @BeforeEach void setUp() throws Exception {
	  
  }
  
  @AfterEach void tearDown() throws Exception{
  
  }
  
  @Test 
  void testSaveCart() { 
	  Cart cart=new Cart(1111,1111,"Pname",7,"Ap",9,99);
  cart=cartService.saveCartProduct(cart); 
  int cid=cart.getCartId();
  cartService.deleteCartItem(cid);
  equals(cart.getProductName());
  
  
  
  }
  
  
  
  @SuppressWarnings("unlikely-arg-type")
@Test 
  void testGetCarts(){
	  Cart cart=new Cart(1111,1111,"Pname",7,"Ap",9,99);
  cart=cartService.saveCartProduct(cart);
  int cid=cart.getCartId();
  cart=cartService.getCartProduct(cid);
  cartService.deleteCartItem(cid);
  equals(cart.getProductName());
  
  
  }
  
  @Test
  void testUpdateCart()
  { 
	  boolean result=false; 
  Cart cart=new Cart(1111,1111,"Pname",7,"Ap",9,99);
  cart=cartService.saveCartProduct(cart); 
  int cid=cart.getCartId();
  cart=new Cart(1111,1111,"Pname",7,"Ap",9,99);
  result=cartService.updateCartItem(cart);
  cartService.deleteCartItem(cid);
  assertEquals(false, result);
  
  }
  
 
  
  @Test 
  void testDeleteCart() {
  boolean result=false; 
  Cart cart=new Cart(1111,1111,"Pname",7,"Ap",9,99);
  cart=cartService.saveCartProduct(cart);
  int cid=cart.getCartId();
  result=cartService.deleteCartItem(cid);
  assertEquals(true, result); 
  }
  
  
  }
  